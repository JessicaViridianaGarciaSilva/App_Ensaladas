package mx.edu.tesoem.meseroaplicacion;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Main2 extends AppCompatActivity {
    ImageButton btnInicio, btnProceso, btnEntregar, btnPagar;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        btnProceso=findViewById(R.id.imgProceso);
        btnEntregar= findViewById(R.id.imgEntregar);
        btnPagar= findViewById(R.id.imgPagar);
        btnInicio= findViewById(R.id.imgInicio);

        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.frameLayout,new Proceso_main())
                .commit();

        btnProceso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, new Proceso_main() )
                        .commit();
            }
        });
        btnEntregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, new Entregar_main())
                        .commit();
            }
        });
        btnPagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, new Pagar_main())
                        .commit();
            }
        });
        btnInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
