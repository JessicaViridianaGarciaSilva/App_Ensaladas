package mx.edu.tesoem.meseroaplicacion.model;

public class entregar {
    String Descripcion,Hora, Mesa, Notas, Total;

    public entregar(String descripcion, String hora, String mesa, String notas, String total) {
        Descripcion = descripcion;
        Hora = hora;
        Mesa = mesa;
        Notas = notas;
        Total = total;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getHora() {
        return Hora;
    }

    public void setHora(String hora) {
        Hora = hora;
    }

    public String getMesa() {
        return Mesa;
    }

    public void setMesa(String mesa) {
        Mesa = mesa;
    }

    public String getNotas() {
        return Notas;
    }

    public void setNotas(String notas) {
        Notas = notas;
    }

    public String getTotal() {
        return Total;
    }

    public void setTotal(String total) {
        Total = total;
    }

    public entregar() {

    }
}
