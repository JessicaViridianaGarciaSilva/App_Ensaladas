package mx.edu.tesoem.meseroaplicacion;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import mx.edu.tesoem.meseroaplicacion.adapter.procesoAdapter;
import mx.edu.tesoem.meseroaplicacion.model.proceso;

public class Proceso_main extends Fragment {

    FirebaseFirestore proFirestore;
    RecyclerView proRecycler;
    procesoAdapter proAdapter;

    Query query;

    public Proceso_main() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_proceso, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        proFirestore=FirebaseFirestore.getInstance();
        proRecycler=view.findViewById(R.id.reciclerViewProceso);
        proRecycler.setLayoutManager(new LinearLayoutManager(getContext()));

        query= proFirestore.collection("enProceso").orderBy("Mesa");
        FirestoreRecyclerOptions<proceso> firestoreRecyclerOptions=
                new FirestoreRecyclerOptions.Builder<proceso>()
                        .setQuery(query, proceso.class).build();
        proAdapter= new procesoAdapter(firestoreRecyclerOptions, getActivity(), getChildFragmentManager());
        proAdapter.notifyDataSetChanged();
        proRecycler.setAdapter(proAdapter);
    }

    @Override
    public void onStart() {
        super.onStart();
            proAdapter.startListening();

    }

    @Override
    public void onStop() {
        super.onStop();
            proAdapter.startListening();
    }
}