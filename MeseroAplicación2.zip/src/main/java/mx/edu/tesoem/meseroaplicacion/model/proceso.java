package mx.edu.tesoem.meseroaplicacion.model;

public class proceso {
    String  Descripcion,Hora, Mesa, Notas, Total;

    public proceso(String mesa, String hora, String notas, String descripcion, String total) {
        Mesa = mesa;
        Hora = hora;
        Notas = notas;
        Descripcion = descripcion;
        Total = total;
    }

    public String getMesa() {
        return Mesa;
    }

    public void setMesa(String mesa) {
        Mesa = mesa;
    }

    public String getHora() {
        return Hora;
    }

    public void setHora(String hora) {
        Hora = hora;
    }

    public String getNotas() {
        return Notas;
    }

    public void setNotas(String notas) {
        Notas = notas;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getTotal() {
        return Total;
    }

    public void setTotal(String total) {
        Total = total;
    }

    public proceso() {

    }
}
