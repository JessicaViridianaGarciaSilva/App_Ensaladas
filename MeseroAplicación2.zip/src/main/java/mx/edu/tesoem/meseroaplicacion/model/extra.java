package mx.edu.tesoem.meseroaplicacion.model;

public class extra {

    String NombreE, PrecioE, CantidadE, ImagenE;

    public extra(String nombreE, String precioE, String cantidadE, String imagenE) {
        NombreE = nombreE;
        PrecioE = precioE;
        CantidadE = cantidadE;
        ImagenE = imagenE;
    }

    public String getNombreE() {
        return NombreE;
    }

    public void setNombreE(String nombreE) {
        NombreE = nombreE;
    }

    public String getPrecioE() {
        return PrecioE;
    }

    public void setPrecioE(String precioE) {
        PrecioE = precioE;
    }

    public String getCantidadE() {
        return CantidadE;
    }

    public void setCantidadE(String cantidadE) {
        CantidadE = cantidadE;
    }

    public String getImagenE() {
        return ImagenE;
    }

    public void setImagenE(String imagenE) {
        ImagenE = imagenE;
    }

    public extra() {
    }
}
