package mx.edu.tesoem.meseroaplicacion;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Productos extends AppCompatActivity {
    //Generamos todas nuestras variables globales para poder usarlas en el codigo
    TextView cantidad, cantidad2, cantidad3, cantidad4, cantidad5,   cantidad6, cantidad7, cantidad8, cantidad9, cantidad10;
    ImageButton btn, btn2, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11,     btn21,btn22,btn23,btn24,btn25,btn26,btn27,btn28, btn29,btn30;
    Button btn3, btnSalir;
    int n=0, n1=0, n2=0, n3=0, n4=0,   n6=0, n7=0, n8=0, n9=0,n10=0;
    int p1=0, p2=0, p3=0, p4=0, p5=0,   p6=0, p7=0,p8=0, p9=0, p10=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productos);

        //Enlazamos los objetos de la clase con el layout
        cantidad = findViewById(R.id.cantidad);
        cantidad2 = findViewById(R.id.cantidad2);
        cantidad3 = findViewById(R.id.cantidad3);
        cantidad4 = findViewById(R.id.cantidad4);
        cantidad5 = findViewById(R.id.cantidad5);

        //Nuevos
        cantidad6 = findViewById(R.id.cantidad6);
        cantidad7 = findViewById(R.id.cantidad7);
        cantidad8 = findViewById(R.id.cantidad8);
        cantidad9 = findViewById(R.id.cantidad9);
        cantidad10 = findViewById(R.id.cantidad10);
        //------------------------
        btn = findViewById(R.id.btnSuma1);
        btn2 = findViewById(R.id.btnResta1);
        btn4 = findViewById(R.id.btnSuma2);
        btn5 = findViewById(R.id.btnResta2);
        btn6 = findViewById(R.id.btnResta3);
        btn7 = findViewById(R.id.btnResta4);
        btn8 = findViewById(R.id.btnResta5);
        btn9 = findViewById(R.id.btnSuma3);
        btn10 = findViewById(R.id.btnSuma4);
        btn11 = findViewById(R.id.btnSuma5);

        //Nuevos
        btn21 = findViewById(R.id.btnSuma6);
        btn22 = findViewById(R.id.btnResta6);

        btn23 = findViewById(R.id.btnSuma7);
        btn24 = findViewById(R.id.btnResta7);

        btn25 = findViewById(R.id.btnSuma8);
        btn26 = findViewById(R.id.btnResta8);

        btn27 = findViewById(R.id.btnSuma9);
        btn28 = findViewById(R.id.btnResta9);

        btn29 = findViewById(R.id.btnSuma10);
        btn30 = findViewById(R.id.btnResta10);

        //----------------------
        btnSalir = findViewById(R.id.btnCancelar);
        btn3 = findViewById(R.id.btnSiguiente);


        //Generamos el metodo del boton cancelar, donde si damos click, finalizamos el activity y sus procesos
        btnSalir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //Se repite las veces necesarias dependiendo de los productos que tengamos
        //-----------------------------------------------------------------------------------------------------------------------
        //Boton donde si le damos click, se le sumara 1 al contador y lo mostrara en la caja de texto, ademas de que sumara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //le decimos que agregue 1 al contador n
                n++;
                //guardamos en la caja de texto el numero del contador y el texto que le coloquemos, despues
                //ponemos un salto de linea por si agrega algun otro elemento
                cantidad.setText(n + "-> Cesar & bacon\r\n");
                //comparamos si el contador vale 1
                if(n==1){
                    //si el contador vale 1, el precio se fijara en 15
                    p1=180;
                }else{
                    //en caso de que el contador no sea 1, se le ira sumando al valor original su mismo precio
                    p1+=180;
                }
            }
        });

        //Boton donde si le damos click, se le restara 1 al contador y lo mostrara en la caja de texto, ademas de que restara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //comparamos si el contador es mayor a 1
                if(n>1) {
                    //si es mayor a 1, le vamos a restar 1 al contador
                    n--;
                    //guardaremos en la caja de texto el texto con el nuevo valor del contador
                    cantidad.setText(n + "-> Cesar & bacon\r\n");
                    //al precio contenido al producto se le va a restar el precio original
                    p1-=180;
                    //comparamos si el contador n es igual a 1
                }else if(n==1){
                    //si el contador es igual a 1, le vamos a restar al contador para que se guarde en 0
                    n--;
                    //y guardaremos la caja de texto vacia para que se vuelva a mostrar el hint
                    cantidad.setText("");
                    //guardaremos el precio en 0, ya que no hay productos agregados
                    p1=0;
                }
            }
        });

        //-----------------------------------------------------------------------------------------------------------------------

        //Boton donde si le damos click, se le sumara 1 al contador y lo mostrara en la caja de texto, ademas de que sumara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1++;
                cantidad2.setText(n1 + "-> Mango y bacon\r\n");
                if(n1==1){
                    p2=200;
                }else{
                    p2+=200;
                }
            }
        });

        //Boton donde si le damos click, se le restara 1 al contador y lo mostrara en la caja de texto, ademas de que restara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(n1>1){
                    n1--;
                    cantidad2.setText(n1 + "-> Mango y bacon\r\n");
                    p2-=200;
                }else if(n1==1){
                    n1--;
                    cantidad2.setText("");
                    p2=0;
                }
            }
        });

        //Boton donde si le damos click, se le sumara 1 al contador y lo mostrara en la caja de texto, ademas de que sumara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n2++;
                cantidad3.setText(n2 + "-> Chipotle rice  \r\n");
                if(n2==1){
                    p3=250;
                }else{
                    p3+=250;
                }
            }
        });

        //Boton donde si le damos click, se le restara 1 al contador y lo mostrara en la caja de texto, ademas de que restara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(n2>1){
                    n2--;
                    cantidad3.setText(n2 + "-> Chipotle rice \r\n");
                    p3-=250;
                }else if(n2==1){
                    n2--;
                    cantidad3.setText("");
                    p3=0;
                }

            }
        });

        //Boton donde si le damos click, se le sumara 1 al contador y lo mostrara en la caja de texto, ademas de que sumara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n3++;
                cantidad4.setText(n3 + "-> Big tuna \r\n");
                if(n3==1){
                    p4=180;
                }else{
                    p4+=180;
                }
            }
        });

        //Boton donde si le damos click, se le restara 1 al contador y lo mostrara en la caja de texto, ademas de que restara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(n3>1){
                    n3--;
                    cantidad4.setText(n3 + "-> Big tuna \r\n");
                    p4-=180;
                }else if(n3==1){
                    n3--;
                    cantidad4.setText("");
                    p4=0;
                }

            }
        });

        //Boton donde si le damos click, se le sumara 1 al contador y lo mostrara en la caja de texto, ademas de que sumara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n4++;
                cantidad5.setText(n4 + "-> Garlic parmesan \r\n");
                if(n4==1){
                    p5=180;
                }else{
                    p5+=180;
                }
            }
        });

        //Boton donde si le damos click, se le restara 1 al contador y lo mostrara en la caja de texto, ademas de que restara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(n4>1){
                    n4--;
                    cantidad5.setText(n4 + " -> Garlic parmesan \r\n");
                    p5-=180;
                }else if(n4==1){
                    n4--;
                    cantidad5.setText("");
                    p5=0;
                }

            }
        });

        //-----------------------------------------------------------------------------------------------------------------------
        //Boton donde si le damos click, se le sumara 1 al contador y lo mostrara en la caja de texto, ademas de que sumara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //le decimos que agregue 1 al contador n
                n6++;
                //guardamos en la caja de texto el numero del contador y el texto que le coloquemos, despues
                //ponemos un salto de linea por si agrega algun otro elemento
                cantidad6.setText(n6 + "-> Caldo de pollo\r\n");
                //comparamos si el contador vale 1
                if(n6==1){
                    //si el contador vale 1, el precio se fijara en 15
                    p6=150;
                }else{
                    //en caso de que el contador no sea 1, se le ira sumando al valor original su mismo precio
                    p6+=150;
                }
            }
        });

        //Boton donde si le damos click, se le restara 1 al contador y lo mostrara en la caja de texto, ademas de que restara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //comparamos si el contador es mayor a 1
                if(n6>1) {
                    //si es mayor a 1, le vamos a restar 1 al contador
                    n6--;
                    //guardaremos en la caja de texto el texto con el nuevo valor del contador
                    cantidad6.setText(n6 + "-> Caldo de pollo\r\n");
                    //al precio contenido al producto se le va a restar el precio original
                    p6-=150;
                    //comparamos si el contador n es igual a 1
                }else if(n6==1){
                    //si el contador es igual a 1, le vamos a restar al contador para que se guarde en 0
                    n6--;
                    //y guardaremos la caja de texto vacia para que se vuelva a mostrar el hint
                    cantidad6.setText("");
                    //guardaremos el precio en 0, ya que no hay productos agregados
                    p6=0;
                }
            }
        });

        //-----------------------------------------------------------------------------------------------------------------------

        //-----------------------------------------------------------------------------------------------------------------------
        //Boton donde si le damos click, se le sumara 1 al contador y lo mostrara en la caja de texto, ademas de que sumara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //le decimos que agregue 1 al contador n
                n7++;
                //guardamos en la caja de texto el numero del contador y el texto que le coloquemos, despues
                //ponemos un salto de linea por si agrega algun otro elemento
                cantidad7.setText(n7 + "-> Sopa de tortilla \r\n");
                //comparamos si el contador vale 1
                if(n7==1){
                    //si el contador vale 1, el precio se fijara en 15
                    p7=150;
                }else{
                    //en caso de que el contador no sea 1, se le ira sumando al valor original su mismo precio
                    p7+=150;
                }
            }
        });

        //Boton donde si le damos click, se le restara 1 al contador y lo mostrara en la caja de texto, ademas de que restara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //comparamos si el contador es mayor a 1
                if(n7>1) {
                    //si es mayor a 1, le vamos a restar 1 al contador
                    n7--;
                    //guardaremos en la caja de texto el texto con el nuevo valor del contador
                    cantidad7.setText(n7 + "-> Sopa de tortilla \r\n");
                    //al precio contenido al producto se le va a restar el precio original
                    p7-=150;
                    //comparamos si el contador n es igual a 1
                }else if(n7==1){
                    //si el contador es igual a 1, le vamos a restar al contador para que se guarde en 0
                    n7--;
                    //y guardaremos la caja de texto vacia para que se vuelva a mostrar el hint
                    cantidad7.setText("");
                    //guardaremos el precio en 0, ya que no hay productos agregados
                    p7=0;
                }
            }
        });

        //-----------------------------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------------------------
        //Boton donde si le damos click, se le sumara 1 al contador y lo mostrara en la caja de texto, ademas de que sumara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //le decimos que agregue 1 al contador n
                n8++;
                //guardamos en la caja de texto el numero del contador y el texto que le coloquemos, despues
                //ponemos un salto de linea por si agrega algun otro elemento
                cantidad8.setText(n8 + "-> Bebida de Fresa \r\n");
                //comparamos si el contador vale 1
                if(n8==1){
                    //si el contador vale 1, el precio se fijara en 15
                    p8=80;
                }else{
                    //en caso de que el contador no sea 1, se le ira sumando al valor original su mismo precio
                    p8+=80;
                }
            }
        });

        //Boton donde si le damos click, se le restara 1 al contador y lo mostrara en la caja de texto, ademas de que restara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //comparamos si el contador es mayor a 1
                if(n8>1) {
                    //si es mayor a 1, le vamos a restar 1 al contador
                    n8--;
                    //guardaremos en la caja de texto el texto con el nuevo valor del contador
                    cantidad8.setText(n8 + "-> Bebida de Fresa\r\n");
                    //al precio contenido al producto se le va a restar el precio original
                    p8-=80;
                    //comparamos si el contador n es igual a 1
                }else if(n8==1){
                    //si el contador es igual a 1, le vamos a restar al contador para que se guarde en 0
                    n8--;
                    //y guardaremos la caja de texto vacia para que se vuelva a mostrar el hint
                    cantidad8.setText("");
                    //guardaremos el precio en 0, ya que no hay productos agregados
                    p8=0;
                }
            }
        });

        //-----------------------------------------------------------------------------------------------------------------------

        //-----------------------------------------------------------------------------------------------------------------------
        //Boton donde si le damos click, se le sumara 1 al contador y lo mostrara en la caja de texto, ademas de que sumara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn27.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //le decimos que agregue 1 al contador n
                n9++;
                //guardamos en la caja de texto el numero del contador y el texto que le coloquemos, despues
                //ponemos un salto de linea por si agrega algun otro elemento
                cantidad9.setText(n9 + "-> Bebida de Pepino\r\n");
                //comparamos si el contador vale 1
                if(n9==1){
                    //si el contador vale 1, el precio se fijara en 15
                    p9=80;
                }else{
                    //en caso de que el contador no sea 1, se le ira sumando al valor original su mismo precio
                    p9+=80;
                }
            }
        });

        //Boton donde si le damos click, se le restara 1 al contador y lo mostrara en la caja de texto, ademas de que restara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn28.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //comparamos si el contador es mayor a 1
                if(n9>1) {
                    //si es mayor a 1, le vamos a restar 1 al contador
                    n9--;
                    //guardaremos en la caja de texto el texto con el nuevo valor del contador
                    cantidad9.setText(n9 + "-> Bebida de Pepino\r\n");
                    //al precio contenido al producto se le va a restar el precio original
                    p9-=80;
                    //comparamos si el contador n es igual a 1
                }else if(n9==1){
                    //si el contador es igual a 1, le vamos a restar al contador para que se guarde en 0
                    n9--;
                    //y guardaremos la caja de texto vacia para que se vuelva a mostrar el hint
                    cantidad9.setText("");
                    //guardaremos el precio en 0, ya que no hay productos agregados
                    p9=0;
                }
            }
        });

        //-----------------------------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------------------------
        //Boton donde si le damos click, se le sumara 1 al contador y lo mostrara en la caja de texto, ademas de que sumara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn29.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //le decimos que agregue 1 al contador n
                n10++;
                //guardamos en la caja de texto el numero del contador y el texto que le coloquemos, despues
                //ponemos un salto de linea por si agrega algun otro elemento
                cantidad10.setText(n10 + "-> Bebida de Mango\r\n");
                //comparamos si el contador vale 1
                if(n10==1){
                    //si el contador vale 1, el precio se fijara en 15
                    p10=80;
                }else{
                    //en caso de que el contador no sea 1, se le ira sumando al valor original su mismo precio
                    p10+=80;
                }
            }
        });

        //Boton donde si le damos click, se le restara 1 al contador y lo mostrara en la caja de texto, ademas de que restara
        //el total a una variable dependiendo del precio del producto que seleccionemos
        btn30.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //comparamos si el contador es mayor a 1
                if(n10>1) {
                    //si es mayor a 1, le vamos a restar 1 al contador
                    n10--;
                    //guardaremos en la caja de texto el texto con el nuevo valor del contador
                    cantidad10.setText(n10 + "-> Bebida de Mango \r\n");
                    //al precio contenido al producto se le va a restar el precio original
                    p10-=80;
                    //comparamos si el contador n es igual a 1
                }else if(n10==1){
                    //si el contador es igual a 1, le vamos a restar al contador para que se guarde en 0
                    n10--;
                    //y guardaremos la caja de texto vacia para que se vuelva a mostrar el hint
                    cantidad10.setText("");
                    //guardaremos el precio en 0, ya que no hay productos agregados
                    p10=0;
                }
            }
        });

        //-----------------------------------------------------------------------------------------------------------------------



        //Generamos la accion del boton "Siguiente", donde verificara que al menos se haya pedido una cosa, si no se ha
        //agregado nada, mostrara una notificacion en pantalla que dira que no se agregaron elementos
        //si cumple con los requisitos solicitados pasa a la siguiente actividad.
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //creamos un intent, en donde al presionar el boton nos mandara a la otra activity
                Intent intent = new Intent(Productos.this, ConfirmarPedido.class);

                //hacemos la comparacion para que detecte si alguno de los campos tiene algo, si no tiene nada, nos mostrara
                //una notificacion en pantalla
                if(n==0 && n1==0 && n2==0 && n3==0 && n4==0 && n6==0 && n7==0 && n8==0 && n9==0 && n10==0){
                    Toast.makeText(getApplicationContext(), "No se agregaron elementos", Toast.LENGTH_SHORT).show();
                //en caso contrario entramos a la otra parte del if
                }else {

                    //Los siguientes procesos se realizan la cantidad de veces necesarias dependiendo de los datos que vayamos
                    //a guardar dentro de las cajas de texto siguientes

                    //en esta parte guardamos el contenido de lo que querramos, en este caso en el cuadro de texto que contiene
                    //el numero del contador y el nombre del producto seleccionado
                    intent.putExtra("texto", cantidad.getText().toString());
                    //hacemos la comparacion donde si el precio es mayor a 0, guardara el precio que se obtenga y le agregamos un
                    //salto de linea para los siguientes precios que se agreguen
                    if(p1>0) {
                        intent.putExtra("precio1", "" + p1 + "\r\n");
                    }else{
                        //en el caso donde el precio sea menor o igual a 0, la caja de texto se guardara como vacia, pues no queremos
                        //que en la caja de texto salga el 0
                        intent.putExtra("precio1", "");
                    }

                    intent.putExtra("texto2", cantidad2.getText().toString());
                    if(p2>0) {
                        intent.putExtra("precio2", "" + p2 + "\r\n");
                    }else{
                        intent.putExtra("precio2", "");
                    }

                    intent.putExtra("texto3", cantidad3.getText().toString());
                    if(p3>0) {
                        intent.putExtra("precio3", "" + p3 + "\r\n");
                    }else{
                        intent.putExtra("precio3", "");
                    }

                    intent.putExtra("texto4", cantidad4.getText().toString());
                    if(p4>0) {
                        intent.putExtra("precio4", "" + p4 + "\r\n");
                    }else{
                        intent.putExtra("precio4", "");
                    }

                    intent.putExtra("texto5", cantidad5.getText().toString());
                    if(p5>0) {
                        intent.putExtra("precio5", "" + p5 + "\r\n");
                    }else{
                        intent.putExtra("precio5", "");
                    }

                    intent.putExtra("texto6", cantidad6.getText().toString());
                    if(p6>0) {
                        intent.putExtra("precio6", "" + p6 + "\r\n");
                    }else{
                        intent.putExtra("precio6", "");
                    }

                    intent.putExtra("texto7", cantidad7.getText().toString());
                    if(p7>0) {
                        intent.putExtra("precio7", "" + p7 + "\r\n");
                    }else{
                        intent.putExtra("precio7", "");
                    }

                    intent.putExtra("texto8", cantidad8.getText().toString());
                    if(p8>0) {
                        intent.putExtra("precio8", "" + p8 + "\r\n");
                    }else{
                        intent.putExtra("precio8", "");
                    }

                    intent.putExtra("texto9", cantidad9.getText().toString());
                    if(p9>0) {
                        intent.putExtra("precio9", "" + p9 + "\r\n");
                    }else{
                        intent.putExtra("precio9", "");
                    }
                    intent.putExtra("texto10", cantidad10.getText().toString());
                    if(p10>0) {
                        intent.putExtra("precio10", "" + p10 + "\r\n");
                    }else{
                        intent.putExtra("precio10", "");
                    }



                    //hacemos la suma de los precios obtenidos para poder obtener el total a pagar
                    int total = p1+p2+p3+p4+p5+p6+p7+p8+p9+p10;
                    intent.putExtra("total", "Total: $" + total);
                    //inicializamos la otra actividad hacia donde se envian nuestros datos que almacenamos con el putExtra
                    startActivity(intent);
                }
            }
        });

    }
}