package mx.edu.tesoem.meseroaplicacion;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ConfirmarPedido extends AppCompatActivity {
    Button cancelar, pedir;

    String id_user; //modificar
    TextView txt, hora, pres, tot;
    EditText nombre, notas;
    //private FirebaseFirestore mfirestore;

    FirebaseFirestore mfirestore = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*if (getArguments()!= null){
            id_user=getArguments().getString("id_user");
        }*/

        setContentView(R.layout.activity_confirmar_pedido);

        mfirestore = FirebaseFirestore.getInstance();

        Date date = new Date();

        nombre = findViewById(R.id.edtNombre);
        notas = findViewById(R.id.edtNotas);

        hora = findViewById(R.id.Hora);
        SimpleDateFormat h = new SimpleDateFormat("h:mm a");
        String shora = h.format(date);
        hora.setText(shora);

        pedir = findViewById(R.id.btnSig);

        cancelar = findViewById(R.id.btnCan);

        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        txt = findViewById(R.id.txtA2Productos);
        pres = findViewById(R.id.precios);
        tot = findViewById(R.id.totalPago);

        Intent intent = getIntent();
        String valor = intent.getStringExtra("nombre");
        Double total = intent.getDoubleExtra("total", 0);

        txt.append(valor);
        pres.append(String.valueOf(total));

        tot.append(String.valueOf(total));

        pedir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Nombre = nombre.getText().toString().trim();
                String Hora = hora.getText().toString().trim();
                String Descripcion = txt.getText().toString().trim();
                String Notas = notas.getText().toString().trim();
                String Total = tot.getText().toString().trim();
                enviarReg(Nombre, Hora, Descripcion, Notas, Total);
                enviarRegAdm(Nombre, Hora, Descripcion, Notas, Total);

            }
        });

    }



    private void enviarReg(String Nombre, String Hora, String Descripcion, String Notas, String Total) {
        Map<String, Object> map = new HashMap<>();
        map.put("Nombre", Nombre);
        map.put("Hora", Hora);
        map.put("Descripcion", Descripcion);
        map.put("Notas", Notas);
        map.put("Total", Total);

        mfirestore.collection("Pedidos").document(Nombre).set(map).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(getApplicationContext(), "Pedido Realizado Correctamente", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ConfirmarPedido.this, Proceso_main.class);
                startActivity(intent);
                finish();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), "Error al realizar el pedido", Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void enviarRegAdm(String Nombre, String Hora, String Descripcion, String Notas, String Total) {
        Map<String, Object> map = new HashMap<>();
        map.put("Nombre", Nombre);
        map.put("Hora", Hora);
        map.put("Descripcion", Descripcion);
        map.put("Notas", Notas);
        map.put("Total", Total);

        mfirestore.collection("RegPedidos").document(Nombre).set(map).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });

    }
}