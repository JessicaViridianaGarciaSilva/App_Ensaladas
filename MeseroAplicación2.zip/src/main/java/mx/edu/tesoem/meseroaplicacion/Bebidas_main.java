package mx.edu.tesoem.meseroaplicacion;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import mx.edu.tesoem.meseroaplicacion.adapter.bebidaAdapter;
import mx.edu.tesoem.meseroaplicacion.model.bebida;

public class Bebidas_main extends AppCompatActivity {

    Button btnmenu;
    FirebaseFirestore bFirestore;
    RecyclerView bRecycler;
    bebidaAdapter bAdapter;
    Query query;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bebidas);

        bFirestore=FirebaseFirestore.getInstance();
        bRecycler=findViewById(R.id.reciclerViewB);
        bRecycler.setLayoutManager(new LinearLayoutManager(this));

        query= bFirestore.collection("Bebidas").orderBy("NombreB");
        FirestoreRecyclerOptions<bebida> firestoreRecyclerOptions=
                new FirestoreRecyclerOptions.Builder<bebida>()
                        .setQuery(query, bebida.class).build();
        bAdapter= new bebidaAdapter(firestoreRecyclerOptions, this, getSupportFragmentManager());
        bAdapter.notifyDataSetChanged();
        bRecycler.setAdapter(bAdapter);
        btnmenu= findViewById(R.id.btnMenu);
        btnmenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Bebidas_main.this, NuevoPedido.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        bAdapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        bAdapter.startListening();
    }
}