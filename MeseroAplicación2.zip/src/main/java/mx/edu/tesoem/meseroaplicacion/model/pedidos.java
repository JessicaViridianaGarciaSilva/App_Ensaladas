package mx.edu.tesoem.meseroaplicacion.model;

public class pedidos {

    //primero se declaran las variables que vamos a tener dentro de nuestra base de datos
    String Nombre, Hora, Descripcion, Notas, Total;
    public pedidos(){}

    //creamos el constructor y los getters y setters de las variables que generamos
    public pedidos(String nombre, String hora, String descripcion, String notas, String total) {
        Nombre = nombre;
        Hora = hora;
        Descripcion = descripcion;
        Notas = notas;
        Total = total;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getHora() {
        return Hora;
    }

    public void setHora(String hora) {
        Hora = hora;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getNotas() {
        return Notas;
    }

    public void setNotas(String notas) {
        Notas = notas;
    }
    public String getTotal() {
        return Total;
    }

    public void setTotal(String total) {
        Total = total;
    }
}
