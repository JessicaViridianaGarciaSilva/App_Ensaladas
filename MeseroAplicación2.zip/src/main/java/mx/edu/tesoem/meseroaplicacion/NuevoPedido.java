package mx.edu.tesoem.meseroaplicacion;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class NuevoPedido extends AppCompatActivity {
    Button btnplatillos, btnbebidas, btnpostres, btnConfirmar, btnInicio;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_nuevo_pedido);

        btnplatillos= findViewById(R.id.btnPlatillos);
        btnbebidas=findViewById(R.id.btnBebidas);
        btnpostres=findViewById(R.id.btnPostres);
        btnConfirmar=findViewById(R.id.btnConfirmar);


        btnplatillos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NuevoPedido.this, Platillos_main.class);
                startActivity(intent);
            }
        });

        btnbebidas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NuevoPedido.this, Bebidas_main.class);
                startActivity(intent);
            }
        });
        btnpostres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NuevoPedido.this, Extras_main.class);
                startActivity(intent);
            }
        });

    }
}