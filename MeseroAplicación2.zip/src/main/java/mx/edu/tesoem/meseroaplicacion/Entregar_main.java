package mx.edu.tesoem.meseroaplicacion;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import mx.edu.tesoem.meseroaplicacion.adapter.entregarAdapter;
import mx.edu.tesoem.meseroaplicacion.adapter.procesoAdapter;
import mx.edu.tesoem.meseroaplicacion.model.entregar;

public class Entregar_main extends Fragment {
    FirebaseFirestore entFirestore;
    RecyclerView entRecycler;
    entregarAdapter entAdapter;

    Query query;

    public Entregar_main() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_entregar_main, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        entFirestore=FirebaseFirestore.getInstance();
        entRecycler=view.findViewById(R.id.reciclerViewEntregar);
        entRecycler.setLayoutManager(new LinearLayoutManager(getContext()));

        query= entFirestore.collection("enEntregar").orderBy("Mesa");
        FirestoreRecyclerOptions<entregar> firestoreRecyclerOptions=
                new FirestoreRecyclerOptions.Builder<entregar>()
                        .setQuery(query, entregar.class).build();
        entAdapter= new entregarAdapter(firestoreRecyclerOptions,getActivity(),getChildFragmentManager());
        entAdapter.notifyDataSetChanged();
        entRecycler.setAdapter(entAdapter);
    }

    @Override
    public void onStart() {
        super.onStart();
        entAdapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        entAdapter.startListening();
    }
}