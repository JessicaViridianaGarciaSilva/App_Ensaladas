package mx.edu.tesoem.meseroaplicacion;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import mx.edu.tesoem.meseroaplicacion.adapter.extraAdapter;
import mx.edu.tesoem.meseroaplicacion.model.extra;

public class Extras_main extends AppCompatActivity {
    Button btnmenu;
    FirebaseFirestore eFirestore;
    RecyclerView eRecycler;
    extraAdapter eAdapter;
    Query query;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_extras);

        eFirestore= FirebaseFirestore.getInstance();
        eRecycler=findViewById(R.id.reciclerViewE);
        eRecycler.setLayoutManager(new LinearLayoutManager(this));

        query=eFirestore.collection("Extras").orderBy("NombreE");
        FirestoreRecyclerOptions<extra> firestoreRecyclerOptions=
                new FirestoreRecyclerOptions.Builder<extra>()
                        .setQuery(query, extra.class).build();
        eAdapter= new extraAdapter(firestoreRecyclerOptions,this,getSupportFragmentManager());
        eAdapter.notifyDataSetChanged();
        eRecycler.setAdapter(eAdapter);
        btnmenu= findViewById(R.id.btnMenu);
        btnmenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Extras_main.this, NuevoPedido.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        eAdapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        eAdapter.startListening();
    }
}