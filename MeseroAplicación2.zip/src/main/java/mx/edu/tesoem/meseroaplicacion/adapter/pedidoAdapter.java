package mx.edu.tesoem.meseroaplicacion.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import mx.edu.tesoem.meseroaplicacion.R;
import mx.edu.tesoem.meseroaplicacion.model.pedidos;



public class pedidoAdapter
        extends FirestoreRecyclerAdapter
        <pedidos, pedidoAdapter.ViewHolder> {
    private FirebaseFirestore mFirestore = FirebaseFirestore.getInstance();
    Activity activity;
    FragmentManager fm;
    public pedidoAdapter(
            @NonNull FirestoreRecyclerOptions
                    <pedidos> options, Activity activity, FragmentManager fm) {
        super(options);
        this.activity = activity;
        this.fm = fm;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView nombre, hora, descripcion, nota, total;
       // Button  modificar; //cambio
        public ViewHolder(@NonNull View itemView){
            super(itemView);
            nombre = itemView.findViewById(R.id.mesa);
            hora = itemView.findViewById(R.id.hora);
            descripcion = itemView.findViewById(R.id.descripcion);
            nota = itemView.findViewById(R.id.nota);
            total = itemView.findViewById(R.id.total);
            //modificar = itemView.findViewById(R.id.modificar); //cambio


        }
    }

    @Override
    protected void onBindViewHolder
            (@NonNull ViewHolder holder,
             int position, @NonNull pedidos model) {
        DocumentSnapshot documentSnapshot = getSnapshots().getSnapshot(holder.getAdapterPosition());//cambio
        final String id = documentSnapshot.getId(); //cambio
        holder.nombre.setText(model.getNombre());
        holder.hora.setText(model.getHora());
        holder.descripcion.setText(model.getDescripcion());
        holder.nota.setText(model.getNotas());
        holder.total.setText(model.getTotal());

        /*cambio
        holder.modificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //enviar datos al fragment
                ConfirmarPedido cr = new ConfirmarPedido();
                Bundle bundle = new Bundle();
                bundle.putString("id_user", id);
            }
        });*/
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.view_proceso,parent,false);
        return new ViewHolder(v);
    }

}
