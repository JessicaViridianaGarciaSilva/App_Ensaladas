package mx.edu.tesoem.meseroaplicacion.adapter;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import mx.edu.tesoem.meseroaplicacion.ConfirmarPedido;
import mx.edu.tesoem.meseroaplicacion.R;
import mx.edu.tesoem.meseroaplicacion.model.platillos;

public class platilloAdapter extends FirestoreRecyclerAdapter <platillos, platilloAdapter.ViewHolder> {
   private FirebaseFirestore mFirestore = FirebaseFirestore.getInstance();
   Activity activity;
   FragmentManager fm;
    public platilloAdapter(
            @NonNull FirestoreRecyclerOptions
                    <platillos> options, Activity activity, FragmentManager fm) {
        super(options);
        this. activity=activity;
        this.fm=fm;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nombreComida, precioComida, cantComida, imgComida;
        Button btnConf;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nombreComida=itemView.findViewById(R.id.Comida);
            precioComida=itemView.findViewById(R.id.Precio);
            cantComida=itemView.findViewById(R.id.Cantidad);
            btnConf = itemView.findViewById(R.id.confCantidad);

        }
    }

    @Override
    protected void onBindViewHolder
            (@NonNull ViewHolder holder,
             int position, @NonNull platillos model) {
        DocumentSnapshot documentSnapshot= getSnapshots().getSnapshot(holder.getBindingAdapterPosition());
        final String id = documentSnapshot.getId();
        holder.nombreComida.setText(model.getNombre());
        holder.precioComida.setText(model.getPrecio());
        holder.cantComida.setText(model.getCantidad());

        holder.btnConf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double cantidad = 0;
                try {
                    cantidad = Double.parseDouble(holder.cantComida.getText().toString());
                } catch (NumberFormatException e) {
                    Toast.makeText(activity.getApplicationContext(), "Por favor, ingrese una cantidad válida", Toast.LENGTH_SHORT).show();
                    return; // Salir del OnClickListener si la cantidad no es un número.
                }

                double total = cantidad * Double.parseDouble(holder.precioComida.getText().toString());

                Intent intent = new Intent(activity, ConfirmarPedido.class);
                intent.putExtra("nombre", holder.nombreComida.getText().toString());
                intent.putExtra("total", total);

                if(cantidad == 0) {
                    Toast.makeText(activity.getApplicationContext(), "No agregó la cantidad", Toast.LENGTH_SHORT).show();
                } else {
                    activity.startActivity(intent);
                }
            }
        });

    }

    @NonNull
    @Override
    public platilloAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.view_platillos,parent,false);
        return new ViewHolder(v);
    }


}
