package mx.edu.tesoem.meseroaplicacion.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import mx.edu.tesoem.meseroaplicacion.Bebidas_main;
import mx.edu.tesoem.meseroaplicacion.R;
import mx.edu.tesoem.meseroaplicacion.model.bebida;

public class bebidaAdapter extends FirestoreRecyclerAdapter<bebida, bebidaAdapter.ViewHolder> {
    private FirebaseFirestore bFirestore = FirebaseFirestore.getInstance();
    Activity activity;
    FragmentManager fm;

    public bebidaAdapter
            (@NonNull FirestoreRecyclerOptions
                    <bebida> options, Activity activity, FragmentManager fm) {
        super(options);
        this.activity= activity;
        this.fm= fm;
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nombreB, precioB, cantidadB, imagenB;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nombreB= itemView.findViewById(R.id.NombreBeb);
            precioB= itemView.findViewById(R.id.PrecioBeb);
            cantidadB= itemView.findViewById(R.id.CantidadBeb);
        }
    }

    @Override
    protected void onBindViewHolder
            (@NonNull bebidaAdapter.ViewHolder holder,
             int position, @NonNull bebida model) {
        DocumentSnapshot documentSnapshot=getSnapshots().getSnapshot(holder.getBindingAdapterPosition());
        final String id = documentSnapshot. getId();
        holder. nombreB.setText(model.getNombreB());
        holder.precioB.setText(model.getPrecioB());
        holder.cantidadB.setText(model.getCnatidadB());

    }

    @NonNull
    @Override
    public bebidaAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.view_bebidas, parent, false);
        return new ViewHolder(v);
    }
}
