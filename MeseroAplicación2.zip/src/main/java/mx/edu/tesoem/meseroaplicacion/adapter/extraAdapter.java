package mx.edu.tesoem.meseroaplicacion.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import mx.edu.tesoem.meseroaplicacion.R;
import mx.edu.tesoem.meseroaplicacion.model.extra;

public class extraAdapter extends FirestoreRecyclerAdapter<extra, extraAdapter.ViewHolder> {
    private FirebaseFirestore eFirestore = FirebaseFirestore.getInstance();
    Activity activity;
    FragmentManager fm;


    public extraAdapter
            (@NonNull FirestoreRecyclerOptions
                    <extra> options, Activity activity, FragmentManager fm) {
        super(options);
        this. activity=activity;
        this.fm=fm;
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nombreExtra, precioExtra, cantExtra, imagenExtra;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nombreExtra=itemView.findViewById(R.id.NombreExtra);
            precioExtra=itemView.findViewById(R.id.PrecioExtra);
            cantExtra=itemView.findViewById(R.id.CantidadExtra);
        }
    }
    @Override
    protected void onBindViewHolder
            (@NonNull ViewHolder holder,
             int position, @NonNull extra model) {
        DocumentSnapshot documentSnapshot=getSnapshots().getSnapshot(holder.getBindingAdapterPosition());
        final String id = documentSnapshot.getId();
        holder.nombreExtra.setText(model.getNombreE());
        holder.precioExtra.setText(model.getPrecioE());
        holder.cantExtra.setText(model.getCantidadE());

    }

    @NonNull
    @Override
    public extraAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.view_extras,parent,false);
        return new ViewHolder(v);
    }
}
