package mx.edu.tesoem.meseroaplicacion.model;

public class platillos {
    String Nombre, Precio, Cantidad, Imagen;

    public platillos(String nombre, String precio, String cantidad, String imagen) {
        Nombre = nombre;
        Precio = precio;
        Cantidad = cantidad;
        Imagen = imagen;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getPrecio() {
        return Precio;
    }

    public void setPrecio(String precio) {
        Precio = precio;
    }

    public String getCantidad() {
        return Cantidad;
    }

    public void setCantidad(String cantidad) {
        Cantidad = cantidad;
    }

    public String getImagen() {
        return Imagen;
    }

    public void setImagen(String imagen) {
        Imagen = imagen;
    }

    public platillos() {
    }
}
