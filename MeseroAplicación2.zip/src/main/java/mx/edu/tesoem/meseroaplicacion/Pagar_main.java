package mx.edu.tesoem.meseroaplicacion;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import mx.edu.tesoem.meseroaplicacion.adapter.entregarAdapter;
import mx.edu.tesoem.meseroaplicacion.adapter.pagarAdapter;
import mx.edu.tesoem.meseroaplicacion.model.pagar;

public class Pagar_main extends Fragment {
    FirebaseFirestore paFirestore;
    RecyclerView paRecycler;
    pagarAdapter paAdapter;

    Query query;

    public Pagar_main() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_pagar_main, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        paFirestore=FirebaseFirestore.getInstance();
        paRecycler=view.findViewById(R.id.reciclerViewPagar);
        paRecycler.setLayoutManager(new LinearLayoutManager(getContext()));

        query= paFirestore.collection("enPagar").orderBy("Mesa");
        FirestoreRecyclerOptions<pagar> firestoreRecyclerOptions=
                new FirestoreRecyclerOptions.Builder<pagar>()
                        .setQuery(query, pagar.class).build();
        paAdapter= new pagarAdapter(firestoreRecyclerOptions,getActivity(), getChildFragmentManager());
        paAdapter.notifyDataSetChanged();
        paRecycler.setAdapter(paAdapter);

    }

    @Override
    public void onStart() {
        super.onStart();
        paAdapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        paAdapter.startListening();
    }
}