package mx.edu.tesoem.meseroaplicacion.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import mx.edu.tesoem.meseroaplicacion.R;
import mx.edu.tesoem.meseroaplicacion.model.entregar;

public class entregarAdapter extends FirestoreRecyclerAdapter<entregar, entregarAdapter.ViewHolder> {
    private FirebaseFirestore entFirestore = FirebaseFirestore.getInstance();
    FragmentActivity activity;
    FragmentManager fm;
    public entregarAdapter
            (@NonNull FirestoreRecyclerOptions
                    <entregar> options, FragmentActivity activity, FragmentManager fm) {
        super(options);
        this.activity= activity;
        this.fm=fm;
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView mesa, hora, notas, descripcion, total;
        ImageButton btnentregar;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mesa=itemView.findViewById(R.id.mesa);
            hora=itemView.findViewById(R.id.hora);
            notas=itemView.findViewById(R.id.nota);
            total=itemView.findViewById(R.id.total);
            descripcion=itemView.findViewById(R.id.descripcion);
            btnentregar = itemView.findViewById(R.id.btnEntregar);
        }
    }

    @Override
    protected void onBindViewHolder
            (@NonNull entregarAdapter.ViewHolder holder,
             int position, @NonNull entregar model) {
        DocumentSnapshot documentSnapshot=getSnapshots().getSnapshot(holder.getBindingAdapterPosition());
        final String id = documentSnapshot.getId();
        holder.mesa.setText(model.getMesa());
        holder.hora.setText(model.getHora());
        holder.notas.setText(model.getNotas());
        holder.descripcion.setText(model.getDescripcion());
        holder.total.setText(model.getTotal());

        holder.btnentregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                transferirDocumento(id);
            }
        });

    }

    private void transferirDocumento(String id){
        DocumentReference docRef = entFirestore.collection("enEntregar").document(id);
        docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if(documentSnapshot.exists()){
                    // Crear una referencia a la nueva colección
                    CollectionReference nuevaColeccionRef = entFirestore.collection("enPagar");
                    // Guardar los datos en la nueva colección
                    nuevaColeccionRef.document(id).set(documentSnapshot.getData())
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    // Una vez confirmada la copia, eliminar el documento original
                                    docRef.delete()
                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void unused) {
                                                    Toast.makeText(activity, "Se ha transferido para PAGAR", Toast.LENGTH_SHORT).show();
                                                }
                                            })
                                            .addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Toast.makeText(activity, "Error al eliminar el documento original", Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(activity, "Error al transferir los datos", Toast.LENGTH_SHORT).show();
                                }
                            });
                } else {
                    Toast.makeText(activity, "El documento no existe", Toast.LENGTH_SHORT).show();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(activity, "Error al obtener el documento", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @NonNull
    @Override
    public entregarAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.view_entregar,parent,false);
        return new ViewHolder(v);
    }


}
