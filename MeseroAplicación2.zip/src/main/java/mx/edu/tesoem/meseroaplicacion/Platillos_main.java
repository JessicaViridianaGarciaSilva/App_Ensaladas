package mx.edu.tesoem.meseroaplicacion;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import mx.edu.tesoem.meseroaplicacion.adapter.platilloAdapter;
import mx.edu.tesoem.meseroaplicacion.model.platillos;

public class Platillos_main extends AppCompatActivity {
    Button btnmenu, editar, btnconfirmar;
    EditText cantidad;
    FirebaseFirestore mFirestore;
    RecyclerView mRecycler;
    platilloAdapter mAdapter;
    Query query;
    //Button btnmenu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_platillos);

        mFirestore= FirebaseFirestore.getInstance();
        mRecycler=findViewById(R.id.reciclerView);
        mRecycler.setLayoutManager(new LinearLayoutManager(this));

        //mostrar registros de platillos
        query= mFirestore.collection("Comida").orderBy("Nombre");
        FirestoreRecyclerOptions<platillos> firestoreRecyclerOptions=
                new FirestoreRecyclerOptions.Builder<platillos>()
                        .setQuery(query, platillos.class).build();
        mAdapter= new platilloAdapter(firestoreRecyclerOptions, this, getSupportFragmentManager());
        mAdapter.notifyDataSetChanged();
        mRecycler.setAdapter(mAdapter);
        editar= findViewById(R.id.btnCambiar2);
        btnmenu= findViewById(R.id.btnMenu);
        btnmenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Platillos_main.this, NuevoPedido.class);
                startActivity(intent);
            }
        });

        btnconfirmar = findViewById(R.id.btnConfirmar);
        btnconfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });


        editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, 1);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            // Obtiene la URI de la imagen seleccionada
            Uri imageUri = data.getData();
            // Actualiza el fondo de pantalla (como lo estabas haciendo)
            ImageView imageView = findViewById(R.id.imageView);
            imageView.setImageURI(imageUri);

        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        mAdapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mAdapter.startListening();
    }
}