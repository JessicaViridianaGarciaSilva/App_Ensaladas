package mx.edu.tesoem.meseroaplicacion.model;

public class bebida {
    String NombreB, PrecioB, CantidadB, ImagenB;

    public bebida(String nombreB, String precioB, String cnatidadB, String imagenB) {
        NombreB = nombreB;
        PrecioB = precioB;
        CantidadB = cnatidadB;
        ImagenB = imagenB;
    }

    public String getNombreB() {
        return NombreB;
    }

    public void setNombreB(String nombreB) {
        NombreB = nombreB;
    }

    public String getPrecioB() {
        return PrecioB;
    }

    public void setPrecioB(String precioB) {
        PrecioB = precioB;
    }

    public String getCnatidadB() {
        return CantidadB;
    }

    public void setCnatidadB(String cnatidadB) {
        CantidadB = cnatidadB;
    }

    public String getImagenB() {
        return ImagenB;
    }

    public void setImagenB(String imagenB) {
        ImagenB = imagenB;
    }

    public bebida() {
    }
}
