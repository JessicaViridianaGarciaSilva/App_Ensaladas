package mx.edu.tesoem.meseroaplicacion.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import mx.edu.tesoem.meseroaplicacion.R;
import mx.edu.tesoem.meseroaplicacion.model.proceso;

public class procesoAdapter extends FirestoreRecyclerAdapter<proceso, procesoAdapter.ViewHolder> {
    private FirebaseFirestore proFirestore = FirebaseFirestore.getInstance();
    FragmentActivity activity;
    FragmentManager fm;
    public procesoAdapter
            (@NonNull FirestoreRecyclerOptions
                    <proceso> options, FragmentActivity activity, FragmentManager fm) {
        super(options);
        this.activity = activity;
        this.fm = fm;
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView mesa, hora, notas, descripcion, total;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mesa=itemView.findViewById(R.id.mesa);
            hora=itemView.findViewById(R.id.hora);
            notas=itemView.findViewById(R.id.nota);
            total=itemView.findViewById(R.id.total);
            descripcion=itemView.findViewById(R.id.descripcion);
        }
    }

    @Override
    protected void onBindViewHolder
            (@NonNull procesoAdapter.ViewHolder holder,
             int position, @NonNull proceso model) {
        DocumentSnapshot documentSnapshot=getSnapshots().getSnapshot(holder.getBindingAdapterPosition());
        final String id = documentSnapshot.getId();
        holder.mesa.setText(model.getMesa());
        holder.hora.setText(model.getHora());
        holder.notas.setText(model.getNotas());
        holder.descripcion.setText(model.getDescripcion());
        holder.total.setText(model.getTotal());
    }

    @NonNull
    @Override
    public procesoAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.view_proceso,parent,false);
        return new ViewHolder(v);
    }


}
