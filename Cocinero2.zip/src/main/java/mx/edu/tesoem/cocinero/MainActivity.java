package mx.edu.tesoem.cocinero;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import mx.edu.tesoem.cocinero.adapter.pedidoAdapter;
import mx.edu.tesoem.cocinero.model.pedido;

public class MainActivity extends AppCompatActivity {

    FirebaseFirestore mFirestore;
    RecyclerView mRecycler;
    pedidoAdapter mAdapter;
    Query query;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFirestore = FirebaseFirestore.getInstance();
        mRecycler=findViewById(R.id.reciclerView);
        mRecycler.setLayoutManager(new LinearLayoutManager(this));

        //mostrar registros
        query= mFirestore.collection("enProceso").orderBy("Mesa");
        FirestoreRecyclerOptions<pedido> firestoreRecyclerOptions =
                new FirestoreRecyclerOptions.Builder<pedido>()
                        .setQuery(query, pedido.class).build();
        mAdapter = new pedidoAdapter(firestoreRecyclerOptions, this, getSupportFragmentManager());
        mAdapter.notifyDataSetChanged();
        mRecycler.setAdapter(mAdapter);

    }

    @Override
    protected void onStart() {
        super.onStart();
        mAdapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mAdapter.startListening();
    }
}