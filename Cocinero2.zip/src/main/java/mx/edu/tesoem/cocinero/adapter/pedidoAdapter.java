package mx.edu.tesoem.cocinero.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import mx.edu.tesoem.cocinero.R;
import mx.edu.tesoem.cocinero.model.pedido;


public class pedidoAdapter
        extends FirestoreRecyclerAdapter
        <pedido, pedidoAdapter.ViewHolder>{

    private FirebaseFirestore mFirestore = FirebaseFirestore.getInstance();
    Activity activity;
    FragmentManager fm;

    public pedidoAdapter(
            @NonNull FirestoreRecyclerOptions
                    <pedido> options, Activity activity, FragmentManager fm) {
        super(options);
        this.activity = activity;
        this.fm = fm;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView mesa, hora, descripcion, nota;
        Button ok;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mesa = itemView.findViewById(R.id.mesa);
            hora = itemView.findViewById(R.id.hora);
            descripcion = itemView.findViewById(R.id.descripcion);
            nota = itemView.findViewById(R.id.nota);
            ok = itemView.findViewById(R.id.btn_realizado);

        }
    }

    @Override
    protected void onBindViewHolder
            (@NonNull ViewHolder holder,
             int position, @NonNull pedido model) {
        DocumentSnapshot documentSnapshot= getSnapshots().getSnapshot(holder.getBindingAdapterPosition());
        final String id = documentSnapshot.getId();
        holder.mesa.setText(model.getMesa());
        holder.hora.setText(model.getHora());
        holder.descripcion.setText(model.getDescripcion());
        holder.nota.setText(model.getNotas());

        holder.ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                transferirDocumento(id);

            }
        });

    }
    private void transferirDocumento(String id){
        DocumentReference docRef = mFirestore.collection("enProceso").document(id);
        docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if (documentSnapshot.exists()) {
                    // Crear una referencia a la nueva colección
                    CollectionReference nuevaColeccionRef = mFirestore.collection("enEntregar");
                    // Guardar los datos en la nueva colección
                    nuevaColeccionRef.document(id).set(documentSnapshot.getData())
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    // Una vez confirmada la copia, eliminar el documento original
                                    docRef.delete()
                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void unused) {
                                                    Toast.makeText(activity, "Documento transferido y eliminado correctamente", Toast.LENGTH_SHORT).show();
                                                }
                                            })
                                            .addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Toast.makeText(activity, "Error al eliminar el documento original", Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(activity, "Error al transferir los datos", Toast.LENGTH_SHORT).show();
                                }
                            });
                } else {
                    Toast.makeText(activity, "El documento no existe", Toast.LENGTH_SHORT).show();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(activity, "Error al obtener el documento", Toast.LENGTH_SHORT).show();
            }
        });
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_pedidos,parent, false);
        return new ViewHolder(v);
    }
}


