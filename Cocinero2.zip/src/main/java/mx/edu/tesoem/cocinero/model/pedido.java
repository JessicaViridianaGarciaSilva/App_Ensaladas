package mx.edu.tesoem.cocinero.model;



public class pedido {

    String  Hora, Descripcion, Notas, Mesa;



    public pedido(){}
    public pedido(String mesa, String hora, String descripcion, String nota) {
        Mesa = mesa;
        Hora = hora;
        Descripcion = descripcion;
        Notas = nota;
    }

    public pedido(String mesa) {
        Mesa = mesa;
    }

    public String getMesa() {
        return Mesa;
    }
    public String getHora() {
        return Hora;
    }

    public void setHora(String hora) {
        Hora = hora;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getNotas() {
        return Notas;
    }

    public void setNota(String nota) {
        Notas = nota;
    }
}
