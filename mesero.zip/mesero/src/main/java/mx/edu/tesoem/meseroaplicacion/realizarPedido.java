package mx.edu.tesoem.meseroaplicacion;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class realizarPedido extends DialogFragment {
    TextView hora;
    EditText nombre, descripcion, notas;
    Button add, rusa, cesar, pollo, dulce, coctel, agua;
    private FirebaseFirestore mfirestore;

    public realizarPedido() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //cambiamos el return por un View, porque se utiliza una vista no un layout estatico
        View v = inflater.inflate(R.layout.fragment_realizar_pedido,container, false);
        mfirestore = FirebaseFirestore.getInstance();

        Date date = new Date();

        //referenciamos el tema de la vista con el del codigo
        nombre = v.findViewById(R.id.edtF1Nombre);
        hora = v.findViewById(R.id.edtF1Hora);
        descripcion = v.findViewById(R.id.edtF1Descripcion);
        notas = v.findViewById(R.id.edtF1Notas);
        add = v.findViewById(R.id.btnF1Pedir);
        rusa = v.findViewById(R.id.btnEnsaladaRusa);
        cesar = v.findViewById(R.id.btnEnsaladaCesar);
        pollo= v.findViewById(R.id.btnEnsaladaPollo);
        dulce = v.findViewById(R.id.btnEnsaladaDulce);
        coctel = v.findViewById(R.id.btnCoctel);
        agua = v.findViewById(R.id.btnAgua);

        //creamos los eventos de los botones de menu
        rusa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                descripcion.append(rusa.getText().toString() + "\r\n");
            }
        });

        cesar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                descripcion.append(cesar.getText().toString()+ "\r\n");
            }
        });

        pollo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                descripcion.append(pollo.getText().toString()+ "\r\n");
            }
        });

        dulce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                descripcion.append(dulce.getText().toString()+ "\r\n");
            }
        });

        coctel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                descripcion.append(coctel.getText().toString()+ "\r\n");
            }
        });

        agua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                descripcion.append(agua.getText().toString()+ "\r\n");
            }
        });




        SimpleDateFormat h = new SimpleDateFormat("h:m a");
        String shora = h.format(date);
        hora.setText(shora);

        //creamos el evento del boton
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Obtenemos el contenido que este almacenado dentro de las cajas de texto
                String Nombre = nombre.getText().toString().trim();
                String Hora = hora.getText().toString().trim();
                String Descripcion = descripcion.getText().toString().trim();
                String Notas = notas.getText().toString().trim();

                //Verificamos que no esten vacias las cajas de texto
                if(Nombre.isEmpty() && Hora.isEmpty() && Descripcion.isEmpty() && Notas.isEmpty()){
                    Toast.makeText(getContext(), "Rellene todos los campos", Toast.LENGTH_SHORT).show();
                }else{
                    enviarReg(Nombre, Hora, Descripcion, Notas);
                }
            }
        });
        return v;
    }

    //Creamos el metodo de enviarReg para poder mandar a la BD en Firestore
    private void enviarReg(String Nombre, String Hora, String Descripcion, String Notas){
        Map<String, Object> map = new HashMap<>();
        map.put("Nombre", Nombre);
        map.put("Hora", Hora);
        map.put("Descripcion", Descripcion);
        map.put("Notas", Notas);

        mfirestore.collection("Pedidos").document(Nombre).set(map).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(getContext(), "Pedido Realizado Correctamente", Toast.LENGTH_SHORT).show();
                getDialog().dismiss();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(), "Error al realizar el pedido", Toast.LENGTH_SHORT).show();
            }
        });
    }
}