package mx.edu.tesoem.meseroaplicacion;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import mx.edu.tesoem.meseroaplicacion.adapter.pedidoAdapter;
import mx.edu.tesoem.meseroaplicacion.model.pedidos;

public class MainActivity extends AppCompatActivity {
    Button add, cha;
    FirebaseFirestore mFirestore;
    RecyclerView mRecycler;
    pedidoAdapter mAdapter;
    Query query;


  @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFirestore = FirebaseFirestore.getInstance();
        mRecycler= findViewById(R.id.reciclerView);
        mRecycler.setLayoutManager(new LinearLayoutManager(this));

        query= mFirestore.collection("Pedidos").orderBy("Hora");
        FirestoreRecyclerOptions<pedidos> firestoreRecyclerOptions=
                new FirestoreRecyclerOptions.Builder<pedidos>()
                        .setQuery(query, pedidos.class).build();
        mAdapter = new pedidoAdapter(firestoreRecyclerOptions, this, getSupportFragmentManager());
        mAdapter.notifyDataSetChanged();
        mRecycler.setAdapter(mAdapter);

        cha = findViewById(R.id.ch);

        cha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Productos.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        mAdapter.startListening();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        mAdapter.startListening();
    }
}