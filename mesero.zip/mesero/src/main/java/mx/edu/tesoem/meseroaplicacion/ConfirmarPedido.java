package mx.edu.tesoem.meseroaplicacion;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ConfirmarPedido extends AppCompatActivity {
    Button cancelar, pedir;

    String id_user; //modificar
    TextView txt, hora, pres, tot;
    EditText nombre, notas;
    //private FirebaseFirestore mfirestore;

    FirebaseFirestore mfirestore = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*if (getArguments()!= null){
            id_user=getArguments().getString("id_user");
        }*/

        setContentView(R.layout.activity_confirmar_pedido);

        mfirestore = FirebaseFirestore.getInstance();

        Date date = new Date();

        nombre = findViewById(R.id.edtNombre);
        notas = findViewById(R.id.edtNotas);

        hora = findViewById(R.id.Hora);
        SimpleDateFormat h = new SimpleDateFormat("h:mm a");
        String shora = h.format(date);
        hora.setText(shora);

        pedir = findViewById(R.id.btnSig);

        cancelar = findViewById(R.id.btnCan);

        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        txt = findViewById(R.id.txtA2Productos);
        pres = findViewById(R.id.precios);
        tot = findViewById(R.id.totalPago);

        Intent intent = getIntent();
        String valor = intent.getStringExtra("texto");
        String precio1 = intent.getStringExtra("precio1");

        String valor2 = intent.getStringExtra("texto2");
        String precio2 = intent.getStringExtra("precio2");

        String valor3 = intent.getStringExtra("texto3");
        String precio3 = intent.getStringExtra("precio3");

        String valor4 = intent.getStringExtra("texto4");
        String precio4 = intent.getStringExtra("precio4");

        String valor5 = intent.getStringExtra("texto5");
        String precio5 = intent.getStringExtra("precio5");

        String valor6 = intent.getStringExtra("texto6");
        String precio6 = intent.getStringExtra("precio6");

        String valor7 = intent.getStringExtra("texto7");
        String precio7 = intent.getStringExtra("precio7");

        String valor8 = intent.getStringExtra("texto8");
        String precio8 = intent.getStringExtra("precio8");

        String valor9 = intent.getStringExtra("texto9");
        String precio9 = intent.getStringExtra("precio9");

        String valor10 = intent.getStringExtra("texto10");
        String precio10 = intent.getStringExtra("precio10");

        String total = intent.getStringExtra("total");

        txt.append(valor);
        pres.append(precio1);

        txt.append(valor2);
        pres.append(precio2);

        txt.append(valor3);
        pres.append(precio3);

        txt.append(valor4);
        pres.append(precio4);

        txt.append(valor5);
        pres.append(precio5);

        txt.append(valor6);
        pres.append(precio6);

        txt.append(valor7);
        pres.append(precio7);

        txt.append(valor8);
        pres.append(precio8);

        txt.append(valor9);
        pres.append(precio9);

        txt.append(valor10);
        pres.append(precio10);

        tot.setText(total);

        pedir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Nombre = nombre.getText().toString().trim();
                String Hora = hora.getText().toString().trim();
                String Descripcion = txt.getText().toString().trim();
                String Notas = notas.getText().toString().trim();
                String Total = tot.getText().toString().trim();

                if(Nombre.isEmpty()){
                    Toast.makeText(getApplicationContext(), "Rellene los campos correspondientes", Toast.LENGTH_SHORT).show();
                }else{
                    enviarReg(Nombre, Hora, Descripcion, Notas, Total);
                    enviarRegAdm(Nombre, Hora, Descripcion, Notas, Total);
                }

            }
        });

    }



    private void enviarReg(String Nombre, String Hora, String Descripcion, String Notas, String Total) {
        Map<String, Object> map = new HashMap<>();
        map.put("Nombre", Nombre);
        map.put("Hora", Hora);
        map.put("Descripcion", Descripcion);
        map.put("Notas", Notas);
        map.put("Total", Total);

        mfirestore.collection("Pedidos").document(Nombre).set(map).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(getApplicationContext(), "Pedido Realizado Correctamente", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ConfirmarPedido.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), "Error al realizar el pedido", Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void enviarRegAdm(String Nombre, String Hora, String Descripcion, String Notas, String Total) {
        Map<String, Object> map = new HashMap<>();
        map.put("Nombre", Nombre);
        map.put("Hora", Hora);
        map.put("Descripcion", Descripcion);
        map.put("Notas", Notas);
        map.put("Total", Total);

        mfirestore.collection("RegPedidos").document(Nombre).set(map).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });

    }

    //cambio
    private  void getModel(String id_user){
        mfirestore.collection("Pedidos").document(id_user).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                String Nombre = documentSnapshot.getString("Nombre");
                String Hora = documentSnapshot.getString("Hora");
                String Descripcion = documentSnapshot.getString("Descripcion");
                String Notas = documentSnapshot.getString("Notas");
                String Total = documentSnapshot.getString("Total");
                nombre.setText(Nombre);
                hora.setText(Hora);
                txt.setText(Descripcion);
                notas.setText(Notas);
                tot.setText(Total);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(),"Error al obtener los datos", Toast.LENGTH_SHORT).show();
            }
        });
    }
}