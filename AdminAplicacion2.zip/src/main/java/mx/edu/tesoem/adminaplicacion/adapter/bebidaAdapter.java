package mx.edu.tesoem.adminaplicacion.adapter;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import mx.edu.tesoem.adminaplicacion.R;
import mx.edu.tesoem.adminaplicacion.agregarBebida;
import mx.edu.tesoem.adminaplicacion.model.bebida;

public class bebidaAdapter extends FirestoreRecyclerAdapter<bebida, bebidaAdapter.ViewHolder> {
    private FirebaseFirestore mFirestore = FirebaseFirestore.getInstance();
    FragmentActivity activity;
    FragmentManager fm;
    public bebidaAdapter
            (@NonNull FirestoreRecyclerOptions
                    <bebida> options, FragmentActivity activity, FragmentManager fm) {
        super(options);
        this.activity= activity;
        this.fm= fm;

    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nombreBebida, precioBebida;
        ImageButton btndelB, btnupdateB;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nombreBebida= itemView.findViewById(R.id.nomBebida);
            precioBebida= itemView.findViewById(R.id.precioBebida);
            btndelB= itemView.findViewById(R.id.btnImgDelB);
            btnupdateB=itemView.findViewById(R.id.btnImgEdtB);
        }
    }

    @Override
    protected void onBindViewHolder
            (@NonNull bebidaAdapter.ViewHolder holder,
             int position, @NonNull bebida model) {
        DocumentSnapshot documentSnapshot= getSnapshots().getSnapshot(holder.getAbsoluteAdapterPosition());
        final String id= documentSnapshot.getId();

        holder.nombreBebida.setText(model.getNombreB());
        holder.precioBebida.setText(model.getPrecioB());
        holder.btnupdateB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                agregarBebida cr= new agregarBebida();
                Bundle bundle= new Bundle();
                bundle.putString("id_bebida", id);
                cr.setArguments(bundle);
                cr.show(fm,"abrir el fragment");
            }
        });

        holder.btndelB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                delBebida(id);
            }
        });

    }

    private void delBebida(String id){
        mFirestore.collection("Bebidas").document(id).delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(activity, "Eliminado correctamente", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(activity, "Error al eliminar ", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @NonNull
    @Override
    public bebidaAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.view_bebida,parent,false);
        return new ViewHolder(v);
    }


}
