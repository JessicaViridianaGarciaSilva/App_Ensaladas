package mx.edu.tesoem.adminaplicacion;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class agregarBebida extends DialogFragment {

    String id_bebida; EditText nomBebida, preBebida; Button btnguardarB, btnelegirB; ImageView imagenB;

    private static final int PICK_IMAGE_REQUEST=1; //nuevo

    FirebaseFirestore mfirestore = FirebaseFirestore.getInstance();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(getArguments()!=null){
            id_bebida=getArguments().getString("id_bebida");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_agregar_bebida, container, false);
        nomBebida= v.findViewById(R.id.edtNombreBebida);
        preBebida= v.findViewById(R.id.edtPrecioBebida);
        imagenB= v.findViewById(R.id.imageBebida);
        btnguardarB= v.findViewById(R.id.btnGuardarB);
        btnelegirB= v.findViewById(R.id.btnElegirImgB);

        btnelegirB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, PICK_IMAGE_REQUEST);
            }
        });

        if (id_bebida == null || id_bebida == ""){
            btnguardarB.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String NombreB = nomBebida.getText().toString().trim();
                    String PrecioB = preBebida.getText().toString().trim();

                    if (NombreB.isEmpty() && PrecioB.isEmpty()){
                        Toast.makeText(getContext(), "Llenar todos los campos", Toast.LENGTH_SHORT).show();
                    }else {
                        enviarRegistroB(NombreB, PrecioB);
                    }
                }
            });
        }else {
            getModel(id_bebida);
            btnguardarB.setText("actualizar");
            btnguardarB.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String NombreB = nomBebida.getText().toString().trim();
                    String PrecioB = preBebida.getText().toString().trim();
                    if(NombreB.isEmpty() && PrecioB.isEmpty()){
                        Toast.makeText(getContext(), "LLenar todos los campos", Toast.LENGTH_SHORT).show();
                    } else {
                        updateRedB(NombreB, PrecioB);
                    }
                }
            });
        }
    return v;
    }
    private void updateRedB(String NombreB, String PrecioB){
        Map<String, Object> map = new HashMap<>();

        map.put("NombreB", NombreB);
        map.put("PrecioB", PrecioB);

        mfirestore.collection("Bebidas").document(id_bebida).update(map).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(getContext(), "actualizado correctamente", Toast.LENGTH_SHORT).show();
                getDialog().dismiss();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(), "Error al actualizar", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void enviarRegistroB (String NombreB, String PrecioB){
        Map<String, Object> map = new HashMap<>();
        map.put("NombreB", NombreB);
        map.put("PrecioB", PrecioB);

        mfirestore.collection("Bebidas").document(NombreB).set(map).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(getContext(),"Creado exitosamente", Toast.LENGTH_SHORT).show();
                getDialog().dismiss();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(),"Error al crear", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getModel(String id_bebida){
        mfirestore.collection("Bebidas").document(id_bebida).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                String NombreB = documentSnapshot.getString("NombreB");
                String PrecioB = documentSnapshot.getString("PrecioB");
                nomBebida.setText(NombreB);
                preBebida.setText(PrecioB);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(),"Error al obtener los datos", Toast.LENGTH_SHORT).show();
            }
        });
    }
}