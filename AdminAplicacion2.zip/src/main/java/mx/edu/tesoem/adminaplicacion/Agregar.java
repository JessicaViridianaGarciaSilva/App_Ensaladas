package mx.edu.tesoem.adminaplicacion;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Agregar extends AppCompatActivity {

    ImageButton btnInicio, btnAddComida, btnAddBebidas, btnAddPostre;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar);

        btnAddComida= findViewById(R.id.imgComida);
        btnAddBebidas= findViewById(R.id.imgBebidas);
        btnAddPostre= findViewById(R.id.imgPostre);

        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.frameLayout,new AddComida())
                .commit();

        btnAddComida.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, new AddComida() )
                        .commit();
            }
        });
        btnAddBebidas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, new AddBebidas())
                        .commit();
            }
        });
        btnAddPostre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, new AddExtra())
                        .commit();
            }
        });

    }
}