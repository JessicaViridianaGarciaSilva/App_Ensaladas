package mx.edu.tesoem.adminaplicacion.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import mx.edu.tesoem.adminaplicacion.R;
import mx.edu.tesoem.adminaplicacion.model.pedido;

public class pedidoAdapter
        extends FirestoreRecyclerAdapter
        <pedido, pedidoAdapter.ViewHolder> {

    private FirebaseFirestore mFirestore= FirebaseFirestore.getInstance();
    Activity activity;
    FragmentManager fm;

    public pedidoAdapter(
            @NonNull FirestoreRecyclerOptions
                    <pedido> options, Activity activity, FragmentManager fm) {
        super(options);
        this.activity = activity;
        this.fm = fm;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView mesa, hora, descripcion, nota;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mesa = itemView.findViewById(R.id.mesa);
            hora = itemView.findViewById(R.id.hora);
            descripcion = itemView.findViewById(R.id.descripcion);
            nota = itemView.findViewById(R.id.nota);

        }
    }

    @Override
    protected void onBindViewHolder
            (@NonNull ViewHolder holder,
             int position, @NonNull pedido model) {
        DocumentSnapshot documentSnapshot= getSnapshots().getSnapshot(holder.getBindingAdapterPosition());
        final String id= documentSnapshot.getId();
        holder.mesa.setText(model.getMesa());
        holder.hora.setText(model.getHora());
        holder.descripcion.setText(model.getDescripcion());
        holder.nota.setText(model.getNotas());

    }

    @NonNull
    @Override
    public pedidoAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_pedidos, parent, false);
        return new ViewHolder(v);
    }


}
