package mx.edu.tesoem.adminaplicacion;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import static android.app.Activity.RESULT_OK;

public class agregarComida extends DialogFragment {

    String id_comida; EditText nomComida, preComida; Button btnguardar, btnelegir; ImageView imagen;
    private static final int PICK_IMAGE_REQUEST=1;
    FirebaseFirestore mfirestore = FirebaseFirestore.getInstance();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(getArguments()!=null){
            id_comida= getArguments().getString("id_comida");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_agregar_comida, container, false);
        //Referenciar
        nomComida= v.findViewById(R.id.edtNombreComida);
        preComida= v.findViewById(R.id.edtPrecioComida);
        imagen= v.findViewById(R.id.imageComida);
        btnguardar= v.findViewById(R.id.btnGuardar);
        btnelegir= v.findViewById(R.id.btnElegirImg);

        btnelegir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, PICK_IMAGE_REQUEST);
            }
        });

        if(id_comida == null || id_comida=="") {

            btnguardar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String Nombre = nomComida.getText().toString().trim();
                    String Precio = preComida.getText().toString().trim();

                    if (Nombre.isEmpty() && Precio.isEmpty()) {
                        Toast.makeText(getContext(), "LLenar todos los campos", Toast.LENGTH_SHORT).show();
                    } else {
                        enviarRegistro(Nombre, Precio);
                    }
                }
            });
        }else{

            getModel(id_comida);

            btnguardar.setText("actualizar");
            btnguardar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String Nombre = nomComida.getText().toString().trim();
                    String Precio = preComida.getText().toString().trim();
                    if(Nombre.isEmpty() && Precio.isEmpty()){
                        Toast.makeText(getContext(), "LLenar todos los campos", Toast.LENGTH_SHORT).show();
                    } else {
                        updateRedC(Nombre, Precio);
                    }
                }
            });
        }

        return v;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            // Obtiene la URI de la imagen seleccionada
            Uri imageUri = data.getData();

            // Muestra la imagen en el ImageView
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);
                imagen.setImageBitmap(bitmap);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
/*
    private void subirImagen(Uri imageUri){
        StorageReference storageRef = FirebaseStorage.getInstance().getReference();
        StorageReference imageRef = storageRef.child("images/" + UUID.randomUUID().toString());

        imageRef.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> {
                    // Obtiene la URL de descarga de la imagen
                    imageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                        String imageUrl = uri.toString();
                        // Ahora puedes guardar la URL de la imagen en Firestore junto con el nombre y el precio
                        guardarEnFirestore(imageUrl);
                    });
                })
                .addOnFailureListener(e -> {
                    // Maneja el error al subir la imagen
                    Toast.makeText(getContext(), "Error al subir la imagen", Toast.LENGTH_SHORT).show();
                });
    }*/


    private void updateRedC(String Nombre, String Precio){
        Map<String, Object> map = new HashMap<>();

        map.put("Nombre", Nombre);
        map.put("Precio", Precio);
        mfirestore.collection("Comida").document(id_comida).update(map).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(getContext(), "actualizado correctamente", Toast.LENGTH_SHORT).show();
                getDialog().dismiss();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(), "Error al actualizar", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void enviarRegistro (String Nombre, String Precio){

        Map<String, Object> map= new HashMap<>();
        map.put("Nombre", Nombre);
        map.put("Precio", Precio);

        mfirestore.collection("Comida").document(Nombre).set(map).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(getContext(),"Creado exitosamente", Toast.LENGTH_SHORT).show();
                getDialog().dismiss();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(),"Error al crear", Toast.LENGTH_SHORT).show();
            }
        });
    }
    private  void getModel(String id_comida){
        mfirestore.collection("Comida").document(id_comida).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                String Nombre = documentSnapshot.getString("Nombre");
                String Precio = documentSnapshot.getString("Precio");
                nomComida.setText(Nombre);
                preComida.setText(Precio);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(),"Error al obtener los datos", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
