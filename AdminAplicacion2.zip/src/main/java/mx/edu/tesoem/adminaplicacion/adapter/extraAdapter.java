package mx.edu.tesoem.adminaplicacion.adapter;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import mx.edu.tesoem.adminaplicacion.R;
import mx.edu.tesoem.adminaplicacion.agregarExtra;
import mx.edu.tesoem.adminaplicacion.model.extra;

public class extraAdapter extends FirestoreRecyclerAdapter<extra, extraAdapter.ViewHolder> {

    private FirebaseFirestore mFirestore = FirebaseFirestore.getInstance();
    FragmentActivity activity;
    FragmentManager fm;
    public extraAdapter
            (@NonNull FirestoreRecyclerOptions
                    <extra> options, FragmentActivity activity, FragmentManager fm) {
        super(options);
        this.activity= activity;
        this.fm= fm;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nombreExtra, precioExtra;
        ImageButton btndelE, btnupdateE;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nombreExtra= itemView.findViewById(R.id.nomExtra);
            precioExtra = itemView.findViewById(R.id.precioExtra);
            btndelE = itemView.findViewById(R.id.btnImgDelE);
            btnupdateE = itemView.findViewById(R.id.btnImgEdtE);
        }
    }

    @Override
    protected void onBindViewHolder
            (@NonNull extraAdapter.ViewHolder holder,
             int position, @NonNull extra model) {
        DocumentSnapshot documentSnapshot= getSnapshots().getSnapshot(holder.getAbsoluteAdapterPosition());
        final String id=documentSnapshot.getId();

        holder.nombreExtra.setText(model.getNombreE());
        holder.precioExtra.setText(model.getPrecioE());
        holder.btnupdateE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                agregarExtra cr= new agregarExtra();
                Bundle bundle = new Bundle();
                bundle.putString("id_extra", id);
                cr.setArguments(bundle);
                cr.show(fm, "abrir el fragment");
            }
        });

        holder.btndelE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                delExtra(id);
            }
        });

    }

    private void delExtra(String id){
        mFirestore.collection("Extras").document(id).delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(activity, "Eliminado correctamente", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(activity, "Error al eliminar ", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @NonNull
    @Override
    public extraAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.view_extra, parent, false);
        return new ViewHolder(v);
    }


}
