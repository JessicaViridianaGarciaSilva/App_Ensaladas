package mx.edu.tesoem.adminaplicacion;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class agregarExtra extends DialogFragment {
    String id_extra; EditText nomExtra, preExtra; Button btnguardarE, btnelegirE; ImageView imagenE;

    private static final int PICK_IMAGE_REQUEST=1; //nuevo

    FirebaseFirestore mfirestore = FirebaseFirestore.getInstance();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null){
            id_extra=getArguments().getString("id_extra");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_agregar_postre, container, false);

        nomExtra= v.findViewById(R.id.edtNombrePostre);
        preExtra= v.findViewById(R.id.edtPrecioPostre);
        imagenE= v.findViewById(R.id.imagePostre);
        btnguardarE= v.findViewById(R.id.btnGuardarP);
        btnelegirE= v.findViewById(R.id.btnElegirImgP);

        btnelegirE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, PICK_IMAGE_REQUEST);
            }
        });

        if(id_extra == null || id_extra == ""){
            btnguardarE.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String NombreE = nomExtra.getText().toString().trim();
                    String PrecioE = preExtra.getText().toString().trim();

                    if (NombreE.isEmpty() && PrecioE.isEmpty()){
                        Toast.makeText(getContext(), "Llenar todos los campos", Toast.LENGTH_SHORT).show();
                    }else {
                        enviarRegistroE(NombreE, PrecioE);
                    }
                }
            });
        }else {
            getModel(id_extra);
            btnguardarE.setText("actualizar");
            btnguardarE.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String NombreE = nomExtra.getText().toString().trim();
                    String PrecioE = preExtra.getText().toString().trim();
                    if(NombreE.isEmpty() && PrecioE.isEmpty()){
                        Toast.makeText(getContext(), "LLenar todos los campos", Toast.LENGTH_SHORT).show();
                    } else {
                        updateRedE(NombreE, PrecioE);
                    }
                }
            });
        }
        return v;
    }

    private void updateRedE(String NombreE, String PrecioE){
        Map<String, Object> map = new HashMap<>();
        map.put("NombreE", NombreE);
        map.put("PrecioE", PrecioE);

        mfirestore.collection("Extras").document(id_extra).update(map).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(getContext(), "actualizado correctamente", Toast.LENGTH_SHORT).show();
                getDialog().dismiss();
            }
        }). addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(), "Error al actualizar", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void enviarRegistroE(String NombreE, String PrecioE){
        Map<String, Object> map= new HashMap<>();
        map.put("NombreE", NombreE);
        map.put("PrecioE", PrecioE);

        mfirestore.collection("Extras").document(NombreE).set(map).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(getContext(),"Creado exitosamente", Toast.LENGTH_SHORT).show();
                getDialog().dismiss();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(),"Error al crear", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getModel(String id_extra){
        mfirestore.collection("Extras").document(id_extra).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                String NombreE = documentSnapshot.getString("NombreE");
                String PrecioE = documentSnapshot.getString("PrecioE");
                nomExtra.setText(NombreE);
                preExtra.setText(PrecioE);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(),"Error al obtener los datos", Toast.LENGTH_SHORT).show();
            }
        });
    }
}