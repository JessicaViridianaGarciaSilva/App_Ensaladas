package mx.edu.tesoem.adminaplicacion.model;

public class comida {
    String Nombre, Precio, Imagen;

    public comida(String nombre, String precio, String imagen) {
        Nombre = nombre;
        Precio = precio;
        Imagen = imagen;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getPrecio() {
        return Precio;
    }

    public void setPrecio(String precio) {
        Precio = precio;
    }

    public String getImagen() {
        return Imagen;
    }

    public void setImagen(String imagen) {
        Imagen = imagen;
    }

    public comida() {

    }
}
