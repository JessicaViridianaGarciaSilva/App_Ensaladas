package mx.edu.tesoem.adminaplicacion;

import static android.app.Activity.RESULT_OK;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class EditarFondo extends DialogFragment {

    private static final int REQUEST_IMAGE_PICK = 1;
    private ImageView imageView; // Referencia a la vista ImageView

    // Método estático para crear una nueva instancia del DialogFragment
    public static EditarFondo newInstance(ImageView imageView) {
        EditarFondo fragment = new EditarFondo();
        fragment.imageView = imageView; // Asigna la referencia de la vista
        return fragment;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Cambiar fondo y texto")
                .setMessage("Selecciona una imagen de fondo:")
                .setPositiveButton("Seleccionar imagen", (dialog, which) -> {
                    Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, REQUEST_IMAGE_PICK);
                })
                .setNegativeButton("Cancelar", (dialog, which) -> dialog.dismiss());
        return builder.create();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_PICK && resultCode == getActivity().RESULT_OK && data != null) {
            // Obtiene la URI de la imagen seleccionada
            Uri imageUri = data.getData();
            // Actualiza el fondo de pantalla en la vista ImageView
            imageView.setImageURI(imageUri);

            // También puedes manejar el texto aquí si lo deseas
        }
    }
}
