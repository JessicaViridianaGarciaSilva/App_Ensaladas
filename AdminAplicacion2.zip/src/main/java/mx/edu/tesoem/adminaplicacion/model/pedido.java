package mx.edu.tesoem.adminaplicacion.model;

public class pedido {

    String  Hora, Descripcion, Notas, Mesa;

    public pedido(String hora, String descripcion, String notas, String mesa) {
        Hora = hora;
        Descripcion = descripcion;
        Notas = notas;
        Mesa = mesa;
    }

    public String getHora() {
        return Hora;
    }

    public void setHora(String hora) {
        Hora = hora;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getNotas() {
        return Notas;
    }

    public void setNotas(String notas) {
        Notas = notas;
    }

    public String getMesa() {
        return Mesa;
    }

    public void setMesa(String mesa) {
        Mesa = mesa;
    }

    public pedido() {

    }
}
