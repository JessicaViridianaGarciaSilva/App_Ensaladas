package mx.edu.tesoem.adminaplicacion;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import mx.edu.tesoem.adminaplicacion.adapter.extraAdapter;
import mx.edu.tesoem.adminaplicacion.model.extra;

public class AddExtra extends Fragment {
    Button añadirE;
    FirebaseFirestore mFirestore;
    RecyclerView mRecycler;
    extraAdapter mAdapter;
    Query query;

    public AddExtra() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_extra, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mFirestore= FirebaseFirestore.getInstance();
        mRecycler=view.findViewById(R.id.reciclerViewExtra);
        mRecycler.setLayoutManager(new LinearLayoutManager(getContext()));

        query= mFirestore.collection("Extras").orderBy("NombreE");
        FirestoreRecyclerOptions<extra> FirestoreRecyclerOptions =
                new FirestoreRecyclerOptions.Builder<extra>()
                        .setQuery(query, extra.class).build();

        mAdapter = new extraAdapter(FirestoreRecyclerOptions, getActivity(), getChildFragmentManager());
        mAdapter.notifyDataSetChanged();
        mRecycler.setAdapter(mAdapter);

        añadirE = view.findViewById(R.id.btnMasExtra);
        añadirE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                agregarExtra cr= new agregarExtra();
                cr.show(getChildFragmentManager(), "insertar registro");
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        mAdapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        mAdapter.startListening();
    }
}