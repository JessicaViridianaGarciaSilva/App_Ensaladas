package mx.edu.tesoem.adminaplicacion;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import mx.edu.tesoem.adminaplicacion.adapter.pedidoAdapter;
import mx.edu.tesoem.adminaplicacion.model.pedido;

public class Ver extends AppCompatActivity {

    FirebaseFirestore mFirestore;
    RecyclerView mRecycler;
    pedidoAdapter mAdapter;
    Query query;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver);

        mFirestore = FirebaseFirestore.getInstance();
        mRecycler= findViewById(R.id.reciclerViewV);
        mRecycler.setLayoutManager(new LinearLayoutManager(this));

        query= mFirestore.collection("Administracion").orderBy("Mesa");
        FirestoreRecyclerOptions<pedido> firestoreRecyclerOptions=
                new FirestoreRecyclerOptions.Builder<pedido>()
                        .setQuery(query, pedido.class).build();
        mAdapter = new pedidoAdapter(firestoreRecyclerOptions, this, getSupportFragmentManager());
        mAdapter.notifyDataSetChanged();
        mRecycler.setAdapter(mAdapter);

    }

    @Override
    protected void onStart() {
        super.onStart();
        mAdapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mAdapter.startListening();
    }
}