package mx.edu.tesoem.adminaplicacion.model;

public class bebida {
    String NombreB, PrecioB, ImagenB;

    public bebida(String nombreB, String precioB, String imagenB) {
        NombreB = nombreB;
        PrecioB = precioB;
        ImagenB = imagenB;
    }

    public String getNombreB() {
        return NombreB;
    }

    public void setNombreB(String nombreB) {
        NombreB = nombreB;
    }

    public String getPrecioB() {
        return PrecioB;
    }

    public void setPrecioB(String precioB) {
        PrecioB = precioB;
    }

    public String getImagenB() {
        return ImagenB;
    }

    public void setImagenB(String imagenB) {
        ImagenB = imagenB;
    }

    public bebida() {

    }
}
