package mx.edu.tesoem.adminaplicacion.model;

public class extra {
    String NombreE, PrecioE, ImagenE;

    public extra(String nombreE, String precioE, String imagenE) {
        NombreE = nombreE;
        PrecioE = precioE;
        ImagenE = imagenE;
    }

    public String getNombreE() {
        return NombreE;
    }

    public void setNombreE(String nombreE) {
        NombreE = nombreE;
    }

    public String getPrecioE() {
        return PrecioE;
    }

    public void setPrecioE(String precioE) {
        PrecioE = precioE;
    }

    public String getImagenE() {
        return ImagenE;
    }

    public void setImagenE(String imagenE) {
        ImagenE = imagenE;
    }

    public extra() {

    }
}
