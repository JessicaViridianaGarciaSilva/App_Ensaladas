package mx.edu.tesoem.cocinero.model;



public class pedido {

    String Nombre, Hora, Descripcion, Notas;

    public pedido(){}
    public pedido(String nombre, String hora, String descripcion, String nota) {
        Nombre = nombre;
        Hora = hora;
        Descripcion = descripcion;
        Notas = nota;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getHora() {
        return Hora;
    }

    public void setHora(String hora) {
        Hora = hora;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getNotas() {
        return Notas;
    }

    public void setNota(String nota) {
        Notas = nota;
    }
}
