package com.tesoem.conexion.model;

public class usuario {
    // Variables necesarias para nuestra base de datos
   String Descripcion, Hora, Nombre, Total, Nota;

    public String getNota() {
        return Nota;
    }

    public void setNota(String nota) {
        Nota = nota;
    }

    public String getTotal() {
        return Total;
    }

    public void setTotal(String total) {
        Total = total;
    }

    public usuario(String total) {
        Total = total;
    }

    public usuario(){

    }

    public usuario(String descripcion, String hora, String nombre, String total, String nota) {
        this.Descripcion = descripcion;
        Hora = hora;
        Nombre = nombre;
        Descripcion = descripcion;
        Total= total;
        Nota= nota;

    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.Descripcion = Descripcion;
    }

    public String getHora() {return Hora;
    }

    public void setHora(String hora) {Hora = hora;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }
}