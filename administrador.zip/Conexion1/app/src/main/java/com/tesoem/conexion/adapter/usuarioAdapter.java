package com.tesoem.conexion.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.tesoem.conexion.R;
import com.tesoem.conexion.model.usuario;

public class usuarioAdapter extends FirestoreRecyclerAdapter<usuario, usuarioAdapter.ViewHolder> {
    Activity activity;
    FragmentManager fm;
    private FirebaseFirestore mfirestore;

    public usuarioAdapter(@NonNull FirestoreRecyclerOptions<usuario> options, Activity activity, FragmentManager fm) {
        super(options);
        this.activity = activity;
        this.fm = fm;
    }

    @Override
    protected void onBindViewHolder(@NonNull ViewHolder viewHolder, int i, @NonNull usuario usuario) {
        DocumentSnapshot documentSnapshot = getSnapshots().getSnapshot(viewHolder.getAbsoluteAdapterPosition());
        final String id = documentSnapshot.getId();

        viewHolder.des.setText(usuario.getDescripcion());
        viewHolder.hora.setText(usuario.getHora());
        viewHolder.nom.setText(usuario.getNombre());
        viewHolder.tot.setText(usuario.getTotal());
        viewHolder.nota.setText(usuario.getNota());
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_usuario, parent, false);
        return new ViewHolder(v);
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView des, hora, nom, tot, nota;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            des = itemView.findViewById(R.id.descripcion);
            hora = itemView.findViewById(R.id.hora);
            nom = itemView.findViewById(R.id.nombre);
            tot = itemView.findViewById(R.id.total);
            nota= itemView.findViewById(R.id.nota);
        }
    }


}